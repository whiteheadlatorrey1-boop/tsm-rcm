# TSM FinOps Upgrade

Adds the Financial Operations Command Center demo flow:

financial-ui -> reconciliation-war-room -> AI Strategist -> Executive Portal

Next integrations:
- reconciliation engine
- data relay layer
- performance validation
- audit evidence
