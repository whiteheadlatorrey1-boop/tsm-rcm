# TSM Decision Service

A working reference implementation of the reasoning layer: deterministic
rule detection → computed confidence → LLM explanation grounded in
evidence → result written back to the event bus.

## Try it first (no setup required)

```
node demo.js
```

Seeds a few invoices, submits one that looks like a duplicate, and prints
the full decision the service produces. Runs with no API key using an
offline fallback explainer, so you can see the real logic working before
wiring in Groq.

## What's real vs. what's a stand-in

| Piece | Status |
|---|---|
| Rule evaluation (`rules/dup_invoice_v1.js`) | Real, deterministic, no LLM |
| Confidence formula (`confidence.js`) | Real, computed, inspectable |
| Explanation call (`explain.js`) | Real Groq call if `GROQ_API_KEY` is set, otherwise a template fallback so the service still runs |
| Event/decision storage (`events-store.js`, `decisions-store.js`) | JSON files — **replace with your real DB** before production use. The function signatures are the contract; swap the internals. |
| Event bus wiring (`event-bus-adapter.js`) | Written against a generic `.subscribe(type, handler)` API — **check this matches your actual `tsm-event-bus.js` methods** and adjust |

## Wiring into TSM-Consultz

1. Copy this whole `tsm-decision-service/` folder into your repo, e.g. `server/services/tsm-decision-service/`.
2. In `server.js`, after your event bus is initialized:

   ```javascript
   const eventBus = require('./tsm-event-bus');
   const { wireDecisionService } = require('./services/tsm-decision-service/event-bus-adapter');

   wireDecisionService(eventBus);
   ```

3. Set `GROQ_API_KEY` in your environment (Fly.io secrets, not hardcoded — see the note below).
4. Swap `events-store.js` and `decisions-store.js` to point at your real database once you have one for this. Every other file only calls the four functions those two files export, so nothing else needs to change.

## Adding a second rule

Copy `rules/dup_invoice_v1.js` as a starting template, then register it in
`rules/registry.js`. Each rule only needs:

```javascript
{
  rule_id, domain, trigger_event_type,
  evaluate(triggerEvent) { /* return null or a fired result */ }
}
```

Good second candidates, in order of how clean the ground truth is:
1. **SLA breach warning** — pure time-math, no fuzzy matching needed
2. **Credit risk flag** — threshold on a numeric field
3. **MDM duplicate record** — same similarity-scoring pattern as the invoice rule, applied to customer/vendor names instead of amounts

## Closing the loop on confidence

`decisions-store.js` has `recordReviewOutcome(decision_id, wasCorrect)`.
Call this from wherever a human actually reviews a flagged decision (an
approve/reject button in the FinOps war room, for example). Once a rule has
5+ reviewed outcomes, its `historicalPrecision` term in the confidence
formula starts reflecting real accuracy instead of the 0.6 default. This is
the piece that makes "the system gets more accurate over time" a true
statement instead of a slide.

## One security note

Don't hardcode `GROQ_API_KEY` into any `.html` or `.js` file that ships to
the browser — the same mistake that happened previously with
`TSM_PRO_ALPHA_2026` in `ins-tax.html`. Set it as a Fly.io secret
(`fly secrets set GROQ_API_KEY=...`) and only read it server-side via
`process.env.GROQ_API_KEY`, exactly as `explain.js` does here.
